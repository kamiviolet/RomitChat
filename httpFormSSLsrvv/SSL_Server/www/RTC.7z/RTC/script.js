"use strict";
console.log(navigator.mediaDevices.enumerateDevices());


const constraints = window.constraints = {
  audio: true,
  video: true
};
const offerOptions = {
  offerToReceiveAudio: 1,
  offerToReceiveVideo: 1
};

const initBtn = document.querySelector('#init_vid_btn');
const callBtn = document.querySelector('#call_btn');    
const loginunderAliasBut = document.querySelector('#loginAliasBut');    
const brodcastBtn = document.querySelector('#brodcastbut');    
const hangupBtn = document.querySelector('#hangup_btn');
const localCam = document.querySelector('#local_cam');
const remoteCam = document.querySelector('#remote_cam');

let startTime;

callBtn.disabled = true;
//hangupBtn.disabled = true;

let localStream;
let local;
let remote;

initBtn.addEventListener('click', init);
callBtn.addEventListener('click', call);

brodcastBtn.addEventListener('click', hitTheTXTbrodcast);
loginunderAliasBut.addEventListener('click', anouseAliasName);
hangupBtn.addEventListener('click', hangTheFuckingFooneEndCaal);


async function init(e) {
  e.preventDefault();

  initBtn.disabled = true;
  callBtn.disabled = false;

  try {
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    handleInitSuccess(stream);

  } catch (e) {
    handleError(e);
  }
}

function handleInitSuccess(stream) {
  localCam.srcObject = stream;
  localStream = stream;
}

async function call() {
  callBtn.disabled = true;
  hangupBtn.disabled = false;

  startTime = window.performance.now();

  const configuration = {};

  console.log('RTCPeerConnection configuration:', configuration);

  local = new RTCPeerConnection(configuration);
  
  console.log('Created local peer connection object local');

  local.addEventListener('icecandidate', e => {
    console.log("onIceCandidate", e);
    onIceCandidate(local, e);
  });


  try {
    console.log('Local createOffer start');
    const offer = await local.createOffer(offerOptions);
    await onCreateOfferSuccess(offer, local);
  } catch (e) {
    onCreateSessionDescriptionError(e);
  }
}


async function onIceCandidate(pc, event) {
  try {
    await (getOtherPc(pc).addIceCandidate(event.candidate));
    onAddIceCandidateSuccessOrErr(pc);//onAddIceCandidateSuccess(pc);
  } catch (e) {
    //onAddIceCandidateError(pc, e);
    onAddIceCandidateSuccessOrErr(pc, e);
  }
  console.log(`${getName(pc)} ICE candidate:\n${event.candidate ? event.candidate.candidate : '(null)'}`);
}

async function onCreateOfferSuccess(desc, somepeercon) { somepeercon.setLocalDescription(desc); }

function onAddIceCandidateSuccessOrErr(somepeer, possibleErr)
{
   if(!possibleErr)
      console.log("onAddIceCandidateSuccessOrErr OK > ", somepeer);
   else
      console.log("onAddIceCandidateSuccessOrErr ERR >", somepeer, possibleErr);
}

// Error handling

function handleError(error) {
  if (error.name === 'OverconstrainedError') {
    errorMsg(`OverconstrainedError: The constraints could not be satisfied by the available devices. Constraints: ${JSON.stringify(constraints)}`);
  } else if (error.name === 'NotAllowedError') {
    errorMsg('NotAllowedError: Permissions have not been granted to use your camera and ' +
      'microphone, you need to allow the page access to your devices in ' +
      'order for the demo to work.');
  }
  errorMsg(`getUserMedia error: ${error.name}`, error);
}

function errorMsg(msg, error) {
  const errorElement = document.querySelector('#errorMsg');
  errorElement.innerHTML += `<p>${msg}</p>`;
  if (typeof error !== 'undefined') {
    console.error(error);
  }
}

function onCreateSessionDescriptionError(error) {
  console.log(`Failed to create session description: ${error.toString()}`);
}

function onSetSessionDescriptionError(error) {
  console.log(`Failed to set session description: ${error.toString()}`);
}




// trigered by broadcast button
// prevent form submiting.. 
// colect text from box
async function hitTheTXTbrodcast(e)
{
    e.preventDefault();
    var inputTXTbox = document.querySelector('#message_input');
    WsbroadcastBullshitToAllOthers(inputTXTbox.value);  
}
async function anouseAliasName(e)
{
    e.preventDefault();
    
    let username = document.querySelector('#usernamebox').value;

    if (username && username !== "") {
      document.querySelector('#user_profile > form').classList.add('hide');
      document.querySelector('#user_profile > div').classList.remove('hide');

    } else {
      document.querySelector('#user_profile > form').classList.remove('hide');
    }
    document.querySelector('#user_profile div > p').innerHTML = username;
    
    WsAnouceLoginAliasName();


}

async function hangTheFuckingFooneEndCaal(e)
{
    e.preventDefault();
    
}











