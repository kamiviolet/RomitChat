! function(e) {
  var t = {};

  function n(i) {
    if (t[i]) return t[i].exports;
    var o = t[i] = {
      i: i,
      l: !1,
      exports: {}
    };
    return e[i].call(o.exports, o, o.exports, n), o.l = !0, o.exports
  }
  n.m = e, n.c = t, n.d = function(e, t, i) {
    n.o(e, t) || Object.defineProperty(e, t, {
      enumerable: !0,
      get: i
    })
  }, n.r = function(e) {
    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
      value: "Module"
    }), Object.defineProperty(e, "__esModule", {
      value: !0
    })
  }, n.t = function(e, t) {
    if (1 & t && (e = n(e)), 8 & t) return e;
    if (4 & t && "object" == typeof e && e && e.__esModule) return e;
    var i = Object.create(null);
    if (n.r(i), Object.defineProperty(i, "default", {
        enumerable: !0,
        value: e
      }), 2 & t && "string" != typeof e)
      for (var o in e) n.d(i, o, function(t) {
        return e[t]
      }.bind(null, o));
    return i
  }, n.n = function(e) {
    var t = e && e.__esModule ? function() {
      return e.default
    } : function() {
      return e
    };
    return n.d(t, "a", t), t
  }, n.o = function(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t)
  }, n.p = "", n(n.s = 0)
}([function(e, t, n) {
  "use strict";
  var i, o;
  n.r(t),
    function(e) {
      e.INITIALIZE_WS = "INITIALIZE_WS", e.CONNECT_WS = "CONNECT_WS", e.DISCONNECT_WS = "DISCONNECT_WS", e.WEBSOCKET_EVENT = "WEBSOCKET_EVENT", e.SET_BASE_PATH = "SET_BASE_PATH", e.SET_JWT = "SET_JWT", e.AUTHENTICATE = "AUTHENTICATE", e.LOGGER_EVENT = "LOGGER_EVENT", e.BRIDGE_SEND_BOOLEAN_TO_NATIVE = "BRIDGE_SEND_BOOLEAN_TO_NATIVE", e.BRIDGE_SEND_INTEGER_TO_NATIVE = "BRIDGE_SEND_INTEGER_TO_NATIVE", e.BRIDGE_SEND_STRING_TO_NATIVE = "BRIDGE_SEND_STRING_TO_NATIVE", e.BRIDGE_SEND_OBJECT_TO_NATIVE = "BRIDGE_SEND_OBJECT_TO_NATIVE", e.BRIDGE_RECEIVE_BOOLEAN_FROM_NATIVE = "BRIDGE_RECEIVE_BOOLEAN_FROM_NATIVE", e.BRIDGE_RECEIVE_INTEGER_FROM_NATIVE = "BRIDGE_RECEIVE_INTEGER_FROM_NATIVE", e.BRIDGE_RECEIVE_STRING_FROM_NATIVE = "BRIDGE_RECEIVE_STRING_FROM_NATIVE", e.BRIDGE_RECEIVE_OBJECT_FROM_NATIVE = "BRIDGE_RECEIVE_OBJECT_FROM_NATIVE", e.CCS_DIAGNOSTICS = "CCS_DIAGNOSTICS", e.LICENSE_EVENT = "LICENSE_EVENT", e.VALIDATION_EVENT = "VALIDATION_EVENT", e.INTERNAL_EVENT = "INTERNAL_EVENT"
    }(i || (i = {})),
    function(e) {
      e.IDLE = "IDLE", e.WAIT_PROGRAM_READY = "WAIT_PROGRAM_READY", e.WAIT_CONNECT_RESPONSE = "WAIT_CONNECT_RESPONSE", e.WAIT_AUTHENTICATE_RESPONSE = "WAIT_AUTHENTICATE_RESPONSE", e.RECONNECT_AFTER_DELAY = "RECONNECT_AFTER_DELAY", e.WAIT_CLEAR_ALL = "WAIT_CLEAR_ALL", e.CONNECTION_REFUSED = "CONNECTION_REFUSED", e.CONNECTION_FAILED = "CONNECTION_FAILED", e.SSL_HANDSHAKE_FAILED = "SSL_HANDSHAKE_FAILED", e.READ_FAILED = "READ_FAILED", e.AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED", e.IN_UPDATE = "IN_UPDATE", e.HEARTBEAT_EXPIRED = "HEARTBEAT_EXPIRED", e.CONNECTED = "CONNECTED", e.DISCONNECT_PENDING = "DISCONNECT_PENDING", e.DISCONNECT_REQUESTED = "DISCONNECT_REQUESTED"
    }(o || (o = {}));
  var r, a = o,
    s = function() {
      for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
      var i = Array(e),
        o = 0;
      for (t = 0; t < n; t++)
        for (var r = arguments[t], a = 0, s = r.length; a < s; a++, o++) i[o] = r[a];
      return i
    };
  ! function(e) {
    e[e.LOG = 0] = "LOG", e[e.DEBUG = 1] = "DEBUG", e[e.WARN = 2] = "WARN", e[e.ERROR = 3] = "ERROR"
  }(r || (r = {}));
  var c, E = function() {
    function e() {}
    return e.getLogLevel = function() {
      return this.logLevel
    }, e.setLogLevel = function(e) {
      this.logLevel = e
    }, e.enableDebugging = function() {
      e.debugging = !0
    }, e.disableDebugging = function() {
      e.debugging = !1
    }, e.getDebuggingState = function() {
      return e.debugging
    }, e.log = function() {
      for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
      !e.getDebuggingState() || this.logLevel > r.LOG || console.log.apply(console, s([e.LOGGER_KEY, (new Date).toISOString()], t))
    }, e.warn = function() {
      for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
      !e.getDebuggingState() || e.logLevel > r.WARN || console.warn.apply(console, s([e.LOGGER_KEY, (new Date).toISOString()], t))
    }, e.error = function() {
      for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
      e.getDebuggingState() && console.error.apply(console, s([e.LOGGER_KEY, (new Date).toISOString()], t))
    }, e.debug = function() {
      for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
      !e.getDebuggingState() || e.logLevel > r.DEBUG || console.debug.apply(console, s([e.LOGGER_KEY, (new Date).toISOString()], t))
    }, e.LOGGER_KEY = "[WXP]", e.logLevel = r.WARN, e.debugging = !0, e
  }();

  function u(e) {
    for (var t = "", n = e.length, i = 0; i < n; i++) {
      var o = e[i].toString(16);
      1 === o.length && (o = "0" + o), t += o + " "
    }
    return t
  }

  function _(e) {
    if (E.debug("Received a PROGRAM_READY packet: " + u(e)), this.cipClient.state === a.WAIT_PROGRAM_READY) switch (e[3]) {
      case 0:
        E.debug("Status 0x00: Reconnecting after 15s delay"), this.cipClient.transitionTo(a.RECONNECT_AFTER_DELAY), this.cipClient.webSocketClient.disconnect("CONTROL_SYSTEM_NOT_READY"), this.cipClient.webSocketClient.connectAfterDelay(15e3);
        break;
      case 1:
        E.debug("Status 0x01: Waiting for another PROGRAM_READY...");
        break;
      case 2:
        E.debug("Status 0x02: Sending connect event"), this.cipClient.connectToCCS(), this.cipClient.transitionTo(a.WAIT_CONNECT_RESPONSE);
        break;
      default:
        throw new Error("Received an invalid status for PROGRAM_READY")
    } else E.error("Received PROGRAM_READY in an invalid state!")
  }! function(e) {
    e.CONNECT_WS = "CONNECT_WS", e.DISCONNECT_WS = "DISCONNECT_WS", e.ERROR_WS = "ERROR_WS", e.WEB_WORKER_FAILED = "WEB_WORKER_FAILED", e.FETCH_TOKEN_FAILED = "FETCH_TOKEN_FAILED", e.CONNECT_CIP = "CONNECT_CIP", e.DISCONNECT_CIP = "DISCONNECT_CIP", e.INVALID_MAC_ADDRESS = "INVALID_MAC_ADDRESS", e.INVALID_CREDENTIALS = "INVALID_CREDENTIALS", e.AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED", e.AUTHENTICATION_REQUIRED = "AUTHENTICATION_REQUIRED", e.CCS_OFFLINE = "CCS_OFFLINE", e.CCS_ONLINE = "CCS_ONLINE", e.CCS_TRIAL_PERIOD_ON = "CCS_TRIAL_PERIOD_ON", e.CCS_TRIAL_PERIOD_OFF = "CCS_TRIAL_PERIOD_OFF", e.CCS_TRIAL_PERIOD_DAYS = "CCS_TRIAL_PERIOD_DAYS", e.CCS_LICENSE_VALID = "CCS_LICENSE_VALID", e.CCS_LICENSE_INVALID = "CCS_LICENSE_INVALID", e.CCS_LICENSE_SUPPORT_ON = "CCS_LICENSE_SUPPORT_ON", e.CCS_LICENSE_SUPPORT_OFF = "CCS_LICENSE_SUPPORT_OFF", e.CCS_LICENSE_DAYS = "CCS_LICENSE_DAYS", e.CCS_NO_LICENCE_REQ = "CCS_NO_LICENCE_REQ", e.LICENSE_WS = "LICENSE_WS", e.NOT_AUTHORIZED = "NOT_AUTHORIZED"
  }(c || (c = {}));
  var l = c;

  function T(e) {
    postMessage(e)
  }
  var C, p = function(e, t, n) {
      T({
        type: e,
        payload: {
          eventName: t,
          data: n
        }
      })
    },
    d = function(e) {
      p(i.CCS_DIAGNOSTICS, e)
    };

  function N(e) {
    if (E.debug("Received an AUTHENTICATE packet: " + u(e)), this.cipClient.state !== a.WAIT_AUTHENTICATE_RESPONSE) return E.error("Received an AUTHENTICATE_RESPONSE packet in an invalid state!"), void d(l.CCS_OFFLINE);
    var t = e[5];
    switch (t) {
      case 0:
        E.error("CIP Authentication failed!"), this.cipClient.transitionTo(a.AUTHENTICATION_FAILED), T({
          type: i.WEBSOCKET_EVENT,
          payload: {
            eventName: l.AUTHENTICATION_FAILED
          }
        }), d(l.CCS_OFFLINE);
        break;
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
        E.log("Authentication succeeded. Access level is " + t), this.cipClient.transitionTo(a.WAIT_CLEAR_ALL), this.cipClient.initializeUpdateRequest(), this.cipClient.initializeHeartBeat(), d(l.CCS_ONLINE);
        break;
      default:
        throw d(l.CCS_OFFLINE), new Error("Invalid access level received on AUTHENTICATE_RESPONSE!")
    }
  }! function(e) {
    e[e.DIGITAL_IO = 0] = "DIGITAL_IO", e[e.ANALOG_IO = 1] = "ANALOG_IO", e[e.COMMAND_PACKETS = 3] = "COMMAND_PACKETS", e[e.SYMMETRICAL_ANALOG_PACKETS = 20] = "SYMMETRICAL_ANALOG_PACKETS", e[e.SERIAL_IO_INDIRECT_TEXT = 21] = "SERIAL_IO_INDIRECT_TEXT", e[e.REPEAT_DIGITAL_IO = 39] = "REPEAT_DIGITAL_IO", e[e.GENERAL_RCB = 30] = "GENERAL_RCB", e[e.EXTENDED_LENGTH_SERIAL_INDIRECT_TEXT = 52] = "EXTENDED_LENGTH_SERIAL_INDIRECT_TEXT", e[e.UNMANGLED_INDIRECT_TEXT_SUPPORT = 42] = "UNMANGLED_INDIRECT_TEXT_SUPPORT", e[e.SMART_OBJECT = 56] = "SMART_OBJECT", e[e.EXTENDED_SMART_OBJECT = 57] = "EXTENDED_SMART_OBJECT", e[e.TIME_AND_DATE = 8] = "TIME_AND_DATE"
  }(C || (C = {}));
  var I = C,
    h = function(e, t, n, i) {
      return new(n || (n = Promise))((function(o, r) {
        function a(e) {
          try {
            c(i.next(e))
          } catch (e) {
            r(e)
          }
        }

        function s(e) {
          try {
            c(i.throw(e))
          } catch (e) {
            r(e)
          }
        }

        function c(e) {
          var t;
          e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
            e(t)
          }))).then(a, s)
        }
        c((i = i.apply(e, t || [])).next())
      }))
    },
    f = function(e, t) {
      var n, i, o, r, a = {
        label: 0,
        sent: function() {
          if (1 & o[0]) throw o[1];
          return o[1]
        },
        trys: [],
        ops: []
      };
      return r = {
        next: s(0),
        throw: s(1),
        return: s(2)
      }, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
        return this
      }), r;

      function s(r) {
        return function(s) {
          return function(r) {
            if (n) throw new TypeError("Generator is already executing.");
            for (; a;) try {
              if (n = 1, i && (o = 2 & r[0] ? i.return : r[0] ? i.throw || ((o = i.return) && o.call(i), 0) : i.next) && !(o = o.call(i, r[1])).done) return o;
              switch (i = 0, o && (r = [2 & r[0], o.value]), r[0]) {
                case 0:
                case 1:
                  o = r;
                  break;
                case 4:
                  return a.label++, {
                    value: r[1],
                    done: !1
                  };
                case 5:
                  a.label++, i = r[1], r = [0];
                  continue;
                case 7:
                  r = a.ops.pop(), a.trys.pop();
                  continue;
                default:
                  if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== r[0] && 2 !== r[0])) {
                    a = 0;
                    continue
                  }
                  if (3 === r[0] && (!o || r[1] > o[0] && r[1] < o[3])) {
                    a.label = r[1];
                    break
                  }
                  if (6 === r[0] && a.label < o[1]) {
                    a.label = o[1], o = r;
                    break
                  }
                  if (o && a.label < o[2]) {
                    a.label = o[2], a.ops.push(r);
                    break
                  }
                  o[2] && a.ops.pop(), a.trys.pop();
                  continue
              }
              r = t.call(e, a)
            } catch (e) {
              r = [6, e], i = 0
            } finally {
              n = o = 0
            }
            if (5 & r[0]) throw r[1];
            return {
              value: r[0] ? r[1] : void 0,
              done: !0
            }
          }([r, s])
        }
      }
    };

  function R(e) {
    return h(this, void 0, void 0, (function() {
      var t, n, i;
      return f(this, (function(o) {
        switch (o.label) {
          case 0:
            return t = e + "config/contract.cse2j", [4, fetch(t)];
          case 1:
            n = o.sent(), o.label = 2;
          case 2:
            return o.trys.push([2, 5, , 6]), n.ok ? [4, n.json()] : [3, 4];
          case 3:
            return i = o.sent(), E.debug("Contract file loaded successfully."), [2, i];
          case 4:
            return [2, Promise.reject(new Error("Contract file not found at " + t + "."))];
          case 5:
            return o.sent(), [2, Promise.reject(new Error("Contract file contains invalid JSON."))];
          case 6:
            return [2]
        }
      }))
    }))
  }
  var A, S = function(e, t, n, i) {
      return new(n || (n = Promise))((function(o, r) {
        function a(e) {
          try {
            c(i.next(e))
          } catch (e) {
            r(e)
          }
        }

        function s(e) {
          try {
            c(i.throw(e))
          } catch (e) {
            r(e)
          }
        }

        function c(e) {
          var t;
          e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
            e(t)
          }))).then(a, s)
        }
        c((i = i.apply(e, t || [])).next())
      }))
    },
    O = function(e, t) {
      var n, i, o, r, a = {
        label: 0,
        sent: function() {
          if (1 & o[0]) throw o[1];
          return o[1]
        },
        trys: [],
        ops: []
      };
      return r = {
        next: s(0),
        throw: s(1),
        return: s(2)
      }, "function" == typeof Symbol && (r[Symbol.iterator] = function() {
        return this
      }), r;

      function s(r) {
        return function(s) {
          return function(r) {
            if (n) throw new TypeError("Generator is already executing.");
            for (; a;) try {
              if (n = 1, i && (o = 2 & r[0] ? i.return : r[0] ? i.throw || ((o = i.return) && o.call(i), 0) : i.next) && !(o = o.call(i, r[1])).done) return o;
              switch (i = 0, o && (r = [2 & r[0], o.value]), r[0]) {
                case 0:
                case 1:
                  o = r;
                  break;
                case 4:
                  return a.label++, {
                    value: r[1],
                    done: !1
                  };
                case 5:
                  a.label++, i = r[1], r = [0];
                  continue;
                case 7:
                  r = a.ops.pop(), a.trys.pop();
                  continue;
                default:
                  if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== r[0] && 2 !== r[0])) {
                    a = 0;
                    continue
                  }
                  if (3 === r[0] && (!o || r[1] > o[0] && r[1] < o[3])) {
                    a.label = r[1];
                    break
                  }
                  if (6 === r[0] && a.label < o[1]) {
                    a.label = o[1], o = r;
                    break
                  }
                  if (o && a.label < o[2]) {
                    a.label = o[2], a.ops.push(r);
                    break
                  }
                  o[2] && a.ops.pop(), a.trys.pop();
                  continue
              }
              r = t.call(e, a)
            } catch (e) {
              r = [6, e], i = 0
            } finally {
              n = o = 0
            }
            if (5 & r[0]) throw r[1];
            return {
              value: r[0] ? r[1] : void 0,
              done: !0
            }
          }([r, s])
        }
      }
    };
  ! function(e) {
    e.NUMERIC = "numeric", e.BOOLEAN = "boolean", e.STRING = "string", e.REPEAT_DIGITAL = "repeatdigital"
  }(A || (A = {}));
  var v = {
      boolean: {
        0: {
          18494: "Csig.All_Control_Systems_Online_fb",
          18495: "Csig.Control_Systems_Offline_fb"
        }
      }
    },
    g = {
      string: {
        "Csig.Browser_URL": {
          joinId: 28601,
          smartObjectId: 0
        }
      }
    },
    D = function() {
      function e() {}
      return e.getInstance = function() {
        return this.instance || (this.instance = new e), this.instance
      }, e.prototype.loadContractFile = function() {
        var e = this;
        this.setContractFile().catch((function(t) {
          E.warn(t.message, "Using empty contract file."), e.contract = {
            signals: {
              events: {},
              states: {}
            }
          }
        })).finally((function() {
          e.initialized = !0
        }))
      }, e.prototype.setContractFile = function() {
        return S(this, void 0, void 0, (function() {
          var t;
          return O(this, (function(n) {
            switch (n.label) {
              case 0:
                return t = this, [4, R(e.basePath)];
              case 1:
                return t.contract = n.sent(), [2]
            }
          }))
        }))
      }, e.prototype.mapEvent = function(e, t) {
        var n, i;
        if (!this.initialized) throw new Error("Contract file not loaded!");
        var o = e === A.REPEAT_DIGITAL ? A.BOOLEAN : e,
          r = (null === (n = g[o]) || void 0 === n ? void 0 : n[t]) || (null === (i = this.contract.signals.events[o]) || void 0 === i ? void 0 : i[t]);
        if (!r) {
          var a = parseInt(t, 10);
          return isNaN(a) || a < 0 ? (E.debug("Event " + t + " not found in the contract file!"), null) : {
            joinId: a,
            smartObjectId: 0
          }
        }
        return r
      }, e.prototype.mapState = function(e, t, n) {
        var i, o, r, a;
        if (void 0 === t && (t = 0), !this.initialized) throw new Error("Contract file not loaded!");
        var s = (null === (o = null === (i = v[e]) || void 0 === i ? void 0 : i[t]) || void 0 === o ? void 0 : o[n]) || (null === (a = null === (r = this.contract.signals.states[e]) || void 0 === r ? void 0 : r[t]) || void 0 === a ? void 0 : a[n]);
        return s || "fb" + n
      }, e
    }(),
    b = D.getInstance(),
    y = function() {
      for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
      var i = Array(e),
        o = 0;
      for (t = 0; t < n; t++)
        for (var r = arguments[t], a = 0, s = r.length; a < s; a++, o++) i[o] = r[a];
      return i
    };

  function P(e, t) {
    return t ? (e[0] << 8) + e[1] : e[0]
  }

  function L(e, t) {
    void 0 === t && (t = 0);
    for (var n = P(e, !1), o = 2; o < n; o += 2) {
      var r = ((127 & e[o + 1]) << 8) + e[o] + 1,
        a = b.mapState(A.BOOLEAN, t, r);
      128 & e[o + 1] ? (E.log("0x00 - handleDigitalIO", {
        signalName: a,
        value: !1,
        joinId: r,
        smartObjectId: t
      }), T({
        type: i.BRIDGE_RECEIVE_BOOLEAN_FROM_NATIVE,
        payload: {
          signalName: a,
          value: !1
        }
      })) : (E.log("0x00 - handleDigitalIO", {
        signalName: a,
        value: !0,
        joinId: r,
        smartObjectId: t
      }), T({
        type: i.BRIDGE_RECEIVE_BOOLEAN_FROM_NATIVE,
        payload: {
          signalName: a,
          value: !0
        }
      }))
    }
  }

  function m(e, t) {
    void 0 === t && (t = 0);
    var n, o, r = P(e, !1),
      a = !1;
    switch (r) {
      case 3:
        n = e[3], o = e[2] + 1;
        break;
      case 4:
        n = (e[3] << 8) + e[4], o = e[2] + 1;
        break;
      case 5:
        n = (e[4] << 8) + e[5], o = (e[2] << 8) + e[3] + 1;
        break;
      default:
        a = !0;
        for (var s = 2; s < r; s += 4) {
          n = (e[s + 2] << 8) + e[s + 3], o = (e[s] << 8) + e[s + 1] + 1;
          var c = b.mapState(A.NUMERIC, t, o);
          E.log("0x01 - handleAnalogIO", {
            signalName: c,
            value: n,
            joinId: o
          }), T({
            type: i.BRIDGE_RECEIVE_INTEGER_FROM_NATIVE,
            payload: {
              signalName: c,
              value: n
            }
          })
        }
    }
    if (!a) {
      c = b.mapState(A.NUMERIC, t, o);
      E.log("0x01 - handleAnalogIO", {
        signalName: c,
        value: n,
        joinId: o
      }), T({
        type: i.BRIDGE_RECEIVE_INTEGER_FROM_NATIVE,
        payload: {
          signalName: c,
          value: n
        }
      })
    }
  }

  function k(e, t, n) {
    E.log("handleStateSynchronization");
    var o = {
      id: e.cipProgramIdentifier,
      state: t,
      value: n
    };
    T({
      type: i.BRIDGE_RECEIVE_OBJECT_FROM_NATIVE,
      payload: {
        signalName: "Csig.State_Synchronization",
        value: JSON.stringify(o)
      }
    })
  }

  function B(e, t) {
    void 0 === t && (t = 0);
    for (var n = P(e, !1), o = 2; o < n; o += 4) {
      var r = (e[o] << 8) + e[o + 1] + 1,
        a = (e[o + 2] << 8) + e[o + 3],
        s = b.mapState(A.NUMERIC, t, r);
      E.log("0x14 - symmetricalAnalogPackets", {
        signalName: s,
        value: a,
        joinId: r
      }), T({
        type: i.BRIDGE_RECEIVE_INTEGER_FROM_NATIVE,
        payload: {
          signalName: s,
          value: a
        }
      })
    }
  }
  var U = {};

  function G(e, t) {
    void 0 === t && (t = 0);
    for (var n = "", o = P(e, !0), r = (e[3] << 8) + e[4] + 1, a = e[5], s = b.mapState(A.STRING, t, r), c = 6; c < o + 2; c += 4 & a ? 2 : 1) {
      var E = void 0;
      E = 4 & a ? (e[c + 1] << 8) + e[c] : e[c], n += String.fromCharCode(E)
    }
    U[s] = 1 & a ? n : U[s] ? U[s] + n : n, 2 & a && T({
      type: i.BRIDGE_RECEIVE_STRING_FROM_NATIVE,
      payload: {
        signalName: s,
        value: U[s]
      }
    })
  }

  function w(e, t) {
    void 0 === t && (t = 0), E.log("0x15 - serialIOIndirecttext, handled by 0x34"), G(new Uint8Array(y([0], e)), t)
  }

  function W(e, t) {
    void 0 === t && (t = 0);
    for (var n = P(e, !1), o = {
        0: "1",
        1: "0"
      }, r = 10 * ((e[2] << 24) + (e[3] << 16) + (e[4] << 8) + e[5]), a = 6; a < n; a += 5) {
      var s = (e[a] << 8) + e[a + 1] + 1,
        c = e[a + 4],
        u = void 0;
      if (1 & c) u = (e[a + 2] << 8) + e[a + 3], "1" === ("0".repeat(16 - u.toString(2).length) + u.toString(2))[0] && (u = -1 * (parseInt(u.toString(2).replace(/0|1/gi, (function(e) {
        return o[e]
      })), 2) + 1));
      else u = (e[a + 2] << 8) + e[a + 3];
      var _ = b.mapState(A.NUMERIC, t, s);
      E.log("0x1E - handleGeneralRCB", {
        signalName: _,
        time: r,
        value: u,
        joinId: s,
        flags: c
      }), T({
        type: i.BRIDGE_RECEIVE_OBJECT_FROM_NATIVE,
        payload: {
          signalName: _,
          value: JSON.stringify({
            rcb: {
              value: u,
              time: r
            }
          })
        }
      })
    }
  }
  var F, H = {};

  function M(e) {
    switch (E.debug("Received a DATA packet: " + u(e) + "."), e[6]) {
      case I.DIGITAL_IO:
        L(e.slice(5));
        break;
      case I.ANALOG_IO:
        m(e.slice(5));
        break;
      case I.COMMAND_PACKETS:
        ! function(e, t) {
          switch (t[2]) {
            case 0:
              E.log("START OF UPDATE"), k(e, "StartOfUpdate", {
                excludePrefixes: ["Csig"]
              });
              break;
            case 22:
              E.log("END OF UPDATE"), k(e, "EndOfUpdate");
              break;
            case 25:
            case 26:
            case 27:
              break;
            case 28:
              E.log("End of join status query"), e.initializeEndOfJoinStatusResponse()
          }
        }(this.cipClient, e.slice(5));
        break;
      case I.SYMMETRICAL_ANALOG_PACKETS:
        B(e.slice(5));
        break;
      case I.SERIAL_IO_INDIRECT_TEXT:
        w(e.slice(5));
        break;
      case I.GENERAL_RCB:
        W(e.slice(5));
        break;
      case I.UNMANGLED_INDIRECT_TEXT_SUPPORT:
        ! function(e) {
          for (var t = "", n = P(e, !1), o = (e[2] << 8) + e[3] + 1, r = e[4], a = b.mapState(A.STRING, 0, o), s = 5; s <= n; s++) t += String.fromCharCode(e[s]);
          E.log("0x2A - unmangledIndirectTextSupport", {
            signalName: a,
            joinId: o,
            flags: r,
            extendedUnmangledIndirectText: t
          }), H[a] = 1 & r ? t : H[a] ? H[a] + t : t, T({
            type: i.BRIDGE_RECEIVE_STRING_FROM_NATIVE,
            payload: {
              signalName: a,
              value: H[a]
            }
          })
        }(e.slice(5));
        break;
      case I.SMART_OBJECT:
        ! function(e) {
          E.log("0x38 - Smart Object");
          for (var t = e[0], n = 2; n < t;) {
            var i = (e[n] << 24) + (e[n + 1] << 16) + (e[n + 2] << 8) + e[n + 3],
              o = e[n + 4],
              r = e[n + 5],
              a = n + 4,
              s = a + o + 1,
              c = e.slice(a, s);
            switch (r) {
              case I.DIGITAL_IO:
                L(c, i);
                break;
              case I.ANALOG_IO:
                m(c, i);
                break;
              case I.SYMMETRICAL_ANALOG_PACKETS:
                B(c, i);
                break;
              case I.SERIAL_IO_INDIRECT_TEXT:
                w(c, i);
                break;
              case I.GENERAL_RCB:
                W(c, i);
                break;
              default:
                E.error("0x38, unhandled packet " + u(e))
            }
            n += o + 4 + 1
          }
        }(e.slice(5));
        break;
      case I.TIME_AND_DATE:
        break;
      default:
        E.error("Unknown packet received in DATA: " + u(e))
    }
  }

  function V(e) {
    E.debug("Received a DISCONNECT packet: " + u(e)), T({
      type: i.CCS_DIAGNOSTICS,
      payload: {
        connectionStatus: !1
      }
    }), this.cipClient.tryReconnect()
  }

  function j(e) {
    E.debug("Received a DISCONNECT_RESPONSE packet: " + u(e));
    var t = e[6];
    this.cipClient.transitionTo(a.DISCONNECT_PENDING), this.cipClient.webSocketClient.disconnect(t.toString()), this.cipClient.tryReconnect()
  }

  function x(e) {
    switch (E.debug("Received an EXTENDED_DATA packet: " + u(e)), e[7]) {
      case I.EXTENDED_LENGTH_SERIAL_INDIRECT_TEXT:
        G(e.slice(5));
        break;
      case I.EXTENDED_SMART_OBJECT:
        ! function(e) {
          E.log("0x39 - Extended Smart Object");
          for (var t = P(e, !0), n = 3; n < t;) {
            var i = (e[n] << 24) + (e[n + 1] << 16) + (e[n + 2] << 8) + e[n + 3],
              o = (e[n + 4] << 8) + e[n + 5],
              r = e[n + 6],
              a = n + 4,
              s = a + o + 2,
              c = e.slice(a, s);
            switch (r) {
              case I.EXTENDED_LENGTH_SERIAL_INDIRECT_TEXT:
                G(c, i);
                break;
              default:
                E.error("0x39, unhandled packet " + u(e))
            }
            n += o + 6
          }
        }(e.slice(5));
        break;
      default:
        E.warn("Unknown packet received in EXTENDED DATA " + u(e))
    }
  }

  function Y(e) {
    E.debug("Received a HEARTBEAT_RESPONSE packet: " + u(e))
  }! function(e) {
    e[e.DUMMY = 0] = "DUMMY", e[e.CONNECT = 1] = "CONNECT", e[e.CONNECT_RESPONSE = 2] = "CONNECT_RESPONSE", e[e.DISCONNECT = 3] = "DISCONNECT", e[e.DISCONNECT_RESPONSE = 4] = "DISCONNECT_RESPONSE", e[e.DATA = 5] = "DATA", e[e.CONNECT_DHCP = 10] = "CONNECT_DHCP", e[e.AUTHENTICATE = 11] = "AUTHENTICATE", e[e.AUTHENTICATE_RESPONSE = 12] = "AUTHENTICATE_RESPONSE", e[e.HEARTBEAT = 13] = "HEARTBEAT", e[e.HEARTBEAT_RESPONSE = 14] = "HEARTBEAT_RESPONSE", e[e.PROGRAM_READY = 15] = "PROGRAM_READY", e[e.CRESNET_DATA = 16] = "CRESNET_DATA", e[e.EXTENDED_DATA = 18] = "EXTENDED_DATA", e[e.DEVICE_ROUTER_CONNECT = 38] = "DEVICE_ROUTER_CONNECT", e[e.DEVICE_ROUTER_CONNECT_RESPONSE = 39] = "DEVICE_ROUTER_CONNECT_RESPONSE", e[e.LICENSE_INFORMATION_RESPONSE = 42] = "LICENSE_INFORMATION_RESPONSE", e[e.CRPC_CONNECT = 19] = "CRPC_CONNECT", e[e.CRPC_DATA = 20] = "CRPC_DATA"
  }(F || (F = {}));
  var J = F,
    X = 64,
    K = 1,
    z = 64,
    q = 128,
    Q = 48,
    Z = 1,
    $ = 1,
    ee = 16,
    te = 32,
    ne = 64,
    ie = 1024,
    oe = 2048,
    re = 4096,
    ae = 256;
  var se, ce = {
      host: location.hostname,
      ipId: "0x03",
      port: 49200,
      roomId: "",
      tokenUrl: location.origin + "/cws/websocket/getWebSocketToken",
      tokenSource: "CSSelf",
      authToken: ""
    },
    Ee = function() {
      function e() {
        this.setParameters()
      }
      return e.prototype.setParameters = function(e) {
        this._url = null == e ? void 0 : e.url, this._ipId = function(e) {
          var t = e; - 1 === t.indexOf("0x") && (t = "0x" + t);
          var n = parseInt(t, 16);
          if (isNaN(n)) throw new Error(e + " is not a valid number!");
          return n
        }((null == e ? void 0 : e.ipId) || ce.ipId), this._roomId = (null == e ? void 0 : e.roomId) || ce.roomId, this._tokenSource = (null == e ? void 0 : e.tokenSource) || ce.tokenSource, this._tokenUrl = (null == e ? void 0 : e.tokenUrl) || ce.tokenUrl, this._authToken = (null == e ? void 0 : e.authToken) || ce.authToken
      }, e.getInstance = function() {
        return void 0 === e._instance && (e._instance = new e), e._instance
      }, Object.defineProperty(e.prototype, "url", {
        get: function() {
          var e;
          return null === (e = this._url) || void 0 === e ? void 0 : e.toString()
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "ipId", {
        get: function() {
          return this._ipId
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "roomId", {
        get: function() {
          return this._roomId
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "jwt", {
        get: function() {
          return this._jwt
        },
        set: function(e) {
          this._jwt = e
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "tokenSource", {
        get: function() {
          return this._tokenSource
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "tokenUrl", {
        get: function() {
          return this._tokenUrl
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "secureToken", {
        get: function() {
          return this._authToken
        },
        enumerable: !1,
        configurable: !0
      }), e
    }().getInstance();
  ! function(e) {
    e.AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED"
  }(se || (se = {}));
  var ue = se;

  function _e(e) {
    E.debug("Received a DEVICE_ROUTER_CONNECT_RESPONSE packet: " + u(e));
    var t = e.length;
    if (this.cipClient.state === a.WAIT_CONNECT_RESPONSE) {
      if (t < 41) throw new Error("Bad packet received!");
      var n, o = e[5],
        r = e[10],
        s = 31 & o,
        c = a.IDLE;
      if (this.cipClient.virtualConnectionHandle = (e[3] << 8) + e[4], 128 & o) E.log("Access is allowed for " + s + " days"), c = a.WAIT_CLEAR_ALL, n = s, p(i.CCS_DIAGNOSTICS, l.CCS_TRIAL_PERIOD_DAYS, n);
      else switch (s) {
        case 0:
          E.log("Standard connection"), c = a.WAIT_CLEAR_ALL;
          break;
        case 1:
          E.log("Connected with master list entry"), c = a.WAIT_CLEAR_ALL;
          break;
        case 2:
          var _ = "Connection refused! Rejected with master list entry.";
          E.error(_), c = a.CONNECTION_REFUSED, d(l.CCS_OFFLINE);
          break;
        case 3:
          _ = "Connection refused! Connection timed out.";
          E.error(_), c = a.CONNECTION_REFUSED, d(l.CCS_OFFLINE);
          break;
        case 4:
          _ = "Connection refused! Out of licenses.";
          E.error(_), c = a.CONNECTION_REFUSED, d(l.CCS_OFFLINE);
          break;
        case 5:
          _ = "Connection refused! No writer access.";
          E.error(_), c = a.CONNECTION_REFUSED, d(l.CCS_OFFLINE);
          break;
        case 6:
          _ = "Connection refused! User defined type is not licensed";
          E.error(_), c = a.CONNECTION_REFUSED, d(l.CCS_OFFLINE);
          break;
        case 7:
          E.log("Connection ok"), c = a.WAIT_CLEAR_ALL;
          break;
        case 8:
          break;
        case 9:
          E.log("License activation key detected"), c = a.WAIT_CLEAR_ALL;
          break;
        case 10:
          E.error("Connection refused! No license key."), c = a.CONNECTION_REFUSED, d(l.CCS_OFFLINE);
          break;
        case 11:
          _ = "Connection refused! IPID is already allocated";
          E.error(_), c = a.CONNECTION_REFUSED, d(l.CCS_OFFLINE);
          break;
        default:
          _ = "Connection refused! Bits 4-0 of the mode byte cannot be handled.";
          E.error(_), c = a.CONNECTION_REFUSED, d(l.CCS_OFFLINE)
      }
      var C = 1 & r;
      if (64 & o) return E.warn("Authentication is required"), void T({
        type: i.WEBSOCKET_EVENT,
        payload: {
          eventName: l.AUTHENTICATION_REQUIRED
        }
      });
      if (C) return E.warn("Authentication failed!"), this.cipClient.transitionTo(a.AUTHENTICATION_FAILED), this.cipClient.disconnect("AUTHENTICATION_FAILED"), void T({
        type: i.INTERNAL_EVENT,
        payload: {
          name: ue.AUTHENTICATION_FAILED
        }
      });
      if (c === a.CONNECTION_REFUSED) return this.cipClient.cancelExpectedResponseTimeouts(), this.cipClient.transitionTo(c), void this.cipClient.tryReconnect();
      c === a.WAIT_CLEAR_ALL && this.cipClient.resetReconnectTimeout();
      var N = e[6];
      this.cipClient.heartBeatSupported = 1 == (1 & N), this.cipClient.isProgramReadySupported = 2 == (2 & N), this.cipClient.isUnicodeSupported = 4 == (4 & N), this.cipClient.extendedLengthSupported = 8 == (8 & N);
      var I = 48 & N;
      16 === I ? this.cipClient.serialSize = ie : 32 === I ? this.cipClient.serialSize = oe : 48 === I && (this.cipClient.serialSize = re);
      var h = 8 == (8 & r),
        f = 16 == (16 & r);
      if (d(l.CCS_LICENSE_SUPPORT_ON), !h && !f) return E.warn("Licensing is not supported!"), void d(l.CCS_LICENSE_SUPPORT_OFF);
      E.debug("" + JSON.stringify({
        supportsHeartbeat: this.cipClient.heartBeatSupported,
        supportsProgramReady: this.cipClient.isProgramReadySupported,
        supportsUnicode: this.cipClient.isUnicodeSupported,
        supportsExtendedLength: this.cipClient.extendedLengthSupported,
        serialSize: this.cipClient.serialSize
      })), c === a.WAIT_CLEAR_ALL && (T({
        type: i.WEBSOCKET_EVENT,
        payload: {
          eventName: l.CONNECT_CIP,
          eventData: {
            url: Ee.url,
            ipId: Ee.ipId,
            roomId: Ee.roomId,
            tokenSource: Ee.tokenSource,
            tokenUrl: Ee.tokenUrl
          }
        }
      }), this.cipClient.initializeUpdateRequest(), this.cipClient.initializeHeartBeat(), d(l.CCS_ONLINE)), this.cipClient.transitionTo(c)
    } else E.error("Received DEVICE_ROUTER_CONNECT_RESPONSE in an invalid state")
  }

  function le(e) {
    E.debug("Received a HEARTBEAT packet: " + u(e)), this.cipClient.sendHeartBeatResponse(e.slice(5))
  }
  var Te, Ce = function() {
      function e(e) {
        this.cipClient = e, this._handleAuthenticateResponse = N.bind(this), this._handleData = M.bind(this), this._handleDeviceRouterConnectResponse = _e.bind(this), this._handleDisconnect = V.bind(this), this._handleDisconnectResponse = j.bind(this), this._handleExtendedData = x.bind(this), this._handleHeartbeatResponse = Y.bind(this), this._handleHeartbeat = le.bind(this), this._handleProgramReady = _.bind(this), this._handleAuthenticateResponse = N.bind(this)
      }
      return Object.defineProperty(e.prototype, "receivedDeviceRouterConnectResponse", {
        get: function() {
          return this._receivedDeviceRouterConnectResponse
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "receivedLicenseInformationResponse", {
        get: function() {
          return this._receivedLicenseInformationResponse
        },
        enumerable: !1,
        configurable: !0
      }), e.prototype.handle = function(e) {
        var t = e[0];
        switch (this.cipClient.setLastPackedReceivedAt(), t) {
          case J.AUTHENTICATE_RESPONSE:
            this._handleAuthenticateResponse(e);
            break;
          case J.DATA:
            this._handleData(e);
            break;
          case J.DEVICE_ROUTER_CONNECT_RESPONSE:
            this._receivedDeviceRouterConnectResponse = !0, this._handleDeviceRouterConnectResponse(e);
            break;
          case J.DISCONNECT:
            this._handleDisconnect(e);
            break;
          case J.DISCONNECT_RESPONSE:
            this._handleDisconnectResponse(e);
            break;
          case J.EXTENDED_DATA:
            this._handleExtendedData(e);
            break;
          case J.HEARTBEAT_RESPONSE:
            this._handleHeartbeatResponse(e), this.cipClient.resetHeartBeatOutgoing();
            break;
          case J.PROGRAM_READY:
            this._handleProgramReady(e), 2 === e[3] && this._startDeviceRouterConnectTimeout();
            break;
          case J.LICENSE_INFORMATION_RESPONSE:
            break;
          case J.HEARTBEAT:
            this._handleHeartbeat(e);
            break;
          case J.DUMMY:
            E.log("Received a dummy packet");
            break;
          default:
            throw new Error("Event " + (J[t] || t) + " has no handler!")
        }
      }, e.prototype._startDeviceRouterConnectTimeout = function() {
        var e = this;
        this.deviceRouterConnectTimeout || (this.deviceRouterConnectTimeout = setTimeout((function() {
          e.cipClient.state !== a.WAIT_PROGRAM_READY ? (e.receivedDeviceRouterConnectResponse || (E.error("Device router connect response not received within 16 seconds!"), d(l.CCS_LICENSE_SUPPORT_OFF)), e._receivedDeviceRouterConnectResponse = void 0) : e._receivedDeviceRouterConnectResponse = void 0
        }), 16e3))
      }, e.prototype.cancelExpectedResponseTimeouts = function() {
        this.deviceRouterConnectTimeout && (clearInterval(this.deviceRouterConnectTimeout), this.deviceRouterConnectTimeout = void 0), this.licenseInformationTimeout && (this.licenseInformationTimeout = void 0, clearInterval(this.licenseInformationTimeout))
      }, e
    }(),
    pe = {
      initialState: a.IDLE,
      transitions: (Te = {}, Te[a.IDLE] = [a.WAIT_PROGRAM_READY, a.DISCONNECT_PENDING], Te[a.WAIT_PROGRAM_READY] = [a.WAIT_CONNECT_RESPONSE, a.RECONNECT_AFTER_DELAY, a.DISCONNECT_PENDING, a.WAIT_PROGRAM_READY], Te[a.RECONNECT_AFTER_DELAY] = [a.WAIT_PROGRAM_READY], Te[a.DISCONNECT_PENDING] = [a.WAIT_PROGRAM_READY], Te[a.WAIT_CONNECT_RESPONSE] = [a.WAIT_CLEAR_ALL, a.WAIT_AUTHENTICATE_RESPONSE, a.CONNECTION_REFUSED, a.WAIT_PROGRAM_READY, a.IDLE, a.AUTHENTICATION_FAILED], Te[a.WAIT_CLEAR_ALL] = [a.WAIT_PROGRAM_READY, a.DISCONNECT_PENDING], Te[a.WAIT_AUTHENTICATE_RESPONSE] = [a.AUTHENTICATION_FAILED, a.WAIT_CLEAR_ALL], Te[a.AUTHENTICATION_FAILED] = [a.WAIT_AUTHENTICATE_RESPONSE, a.WAIT_PROGRAM_READY], Te[a.CONNECTION_REFUSED] = [a.WAIT_PROGRAM_READY], Te)
    },
    de = [J.CRPC_DATA, J.CONNECT, J.CONNECT_DHCP, J.DEVICE_ROUTER_CONNECT];

  function Ne(e, t, n) {
    void 0 === n && (n = 0);
    var i = de.includes(e) ? 0 : 2,
      o = (t ? t.length : 0) + i,
      r = new Uint8Array(o + 3),
      a = 0;
    return r[a++] = e, r[a++] = o >> 8, r[a++] = 255 & o, de.includes(e) || (r[a++] = n >> 8, r[a++] = 255 & n), t && r.set(t, a), E.log("Built packet:", u(r)), r
  }

  function Ie(e) {
    for (var t = e.length, n = new Uint8Array(t), i = 0, o = 0; o < t; o++) n[i++] = Math.min(e.charCodeAt(o), 255);
    return n
  }

  function he(e, t) {
    var n = new Uint8Array(t);
    return n.set(Ie(e)), n
  }
  var fe = function() {
    function e(e) {
      this._maxHeartBeatAttempts = 3, this._internalHeartBeatInterval = 1e4, this.maxIntervalBetweenPackets = 29e3, this._lastPacketReceivedAt = void 0, this._heartBeatSupported = void 0, this._extendedLengthSupported = void 0, this._unicodeSupported = void 0, this._programReadySupported = void 0, this._serialSize = ae, this._heartBeatTimer = void 0, this._heartBeatOutgoing = 0, this._connected = !1, this._state = pe.initialState, this._webSocketClient = e, this._cipPacketHandler = new Ce(this)
    }
    return e.prototype.cancelExpectedResponseTimeouts = function() {
      this._cipPacketHandler.cancelExpectedResponseTimeouts()
    }, e.prototype.incrementHeartBeatOutgoing = function() {
      this._heartBeatOutgoing++
    }, e.prototype.resetReconnectTimeout = function() {
      this._webSocketClient.reconnectTimeout = 5e3
    }, Object.defineProperty(e.prototype, "heartBeatTimer", {
      get: function() {
        return this._heartBeatTimer
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "heartBeatSupported", {
      get: function() {
        return this._heartBeatSupported
      },
      set: function(e) {
        this._heartBeatSupported = e
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "extendedLengthSupported", {
      get: function() {
        return this._extendedLengthSupported
      },
      set: function(e) {
        this._extendedLengthSupported = e
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "isUnicodeSupported", {
      get: function() {
        return this._unicodeSupported
      },
      set: function(e) {
        this._unicodeSupported = e
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "isProgramReadySupported", {
      get: function() {
        return this._programReadySupported
      },
      set: function(e) {
        this._programReadySupported = e
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "serialSize", {
      get: function() {
        return this._serialSize
      },
      set: function(e) {
        this._serialSize = e
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.resetHeartBeatOutgoing = function() {
      this._heartBeatOutgoing = 0
    }, Object.defineProperty(e.prototype, "heartBeatOutgoing", {
      get: function() {
        return this._heartBeatOutgoing
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "state", {
      get: function() {
        return this._state
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "webSocketClient", {
      get: function() {
        return this._webSocketClient
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "connected", {
      get: function() {
        return this._connected
      },
      set: function(e) {
        E.debug("CIP Connection status changed to:", e), this._connected = e, this.webSocketClient.onCIPConnectionStatusChanged(e)
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.setLastPackedReceivedAt = function() {
      this._lastPacketReceivedAt = (new Date).getTime()
    }, e.prototype.initializeHeartBeat = function() {
      var e = this.heartBeatSupported;
      e || void 0 === this.heartBeatTimer ? e && void 0 === this.heartBeatTimer && (this._heartBeatTimer = setInterval(this.sendHeartBeat.bind(this), this._internalHeartBeatInterval)) : (clearInterval(this.heartBeatTimer), this._heartBeatTimer = void 0, this._lastPacketReceivedAt = void 0)
    }, e.prototype.initializeUpdateRequest = function() {
      this.sendUpdateRequest()
    }, e.prototype.initializeEndOfJoinStatusResponse = function() {
      this.sendEndOfJoinStatusResponse()
    }, e.prototype.transitionTo = function(e) {
      var t = pe.transitions[this._state];
      if (!t || !t.find((function(t) {
          return t === e
        }))) throw new Error("Invalid transition from " + this._state + " to " + e);
      this._state = e
    }, e.prototype.reset = function() {
      this._state = pe.initialState
    }, e.prototype.connectToCCS = function() {
      this.sendDeviceRouterConnect()
    }, e.prototype.handleCIPPacket = function(e) {
      this._cipPacketHandler.handle(new Uint8Array(e))
    }, Object.defineProperty(e.prototype, "virtualConnectionHandle", {
      get: function() {
        return this._virtualConnectionHandle
      },
      set: function(e) {
        this._virtualConnectionHandle = e
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "cipProgramIdentifier", {
      get: function() {
        return this._cipProgramIdentifier
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.authenticate = function() {
      var e = Ee.jwt,
        t = "Crestron:" + Ee.tokenSource + ":" + e,
        n = new Uint8Array(t.length);
      n.set(Ie(t), 0);
      var i = Ne(J.AUTHENTICATE, n, this._virtualConnectionHandle);
      this.transitionTo(a.WAIT_AUTHENTICATE_RESPONSE), this.webSocketClient.sendCIPPacketWithoutBuffer(i)
    }, e.prototype.sendDeviceRouterConnect = function() {
      var e = Ee.ipId,
        t = Ee.roomId,
        n = Ee.jwt,
        i = "Crestron:" + Ee.tokenSource + ":" + n,
        o = i.length,
        r = new Uint8Array(213 + o),
        a = 0;
      E.log("Sending DEVICE_ROUTER_CONNECT_REQUEST to", {
        ipId: e,
        roomId: t
      }), r[a++] = e >> 8, r[a++] = 255 & e, r[a++] = X, r[a++] = K + q + z + Q, r[a++] = Z, r[a++] = 0, r[a++] = 0, r[a++] = 0;
      var s = 0 + ee + te;
      (null == t ? void 0 : t.length) > 0 && (s += $), o > 0 && (s += ne), r[a++] = s, r.set([0, 0, 0, 0, 0, 0], a), a += 6;
      r.set(he("Crestron", 50), a), a += 50;
      r.set(he("WebXPanel", 50), a), a += 50, r.set(he(t, 32), a), a += 32;
      r.set(he("Hostname", 64), a), a += 64, r[a++] = o >> 8, r[a++] = 255 & o, o > 0 && r.set(Ie(i), a), this._cipProgramIdentifier = this.webSocketClient.socket.url + ":0x" + e.toString(16) + ":" + t;
      var c = Ne(J.DEVICE_ROUTER_CONNECT, r);
      this.webSocketClient.sendCIPPacketWithoutBuffer(c)
    }, e.prototype.sendHeartBeat = function() {
      if (!((new Date).getTime() - this._lastPacketReceivedAt < this.maxIntervalBetweenPackets))
        if (this.webSocketClient.connected) {
          if (this.heartBeatOutgoing >= this._maxHeartBeatAttempts) return this.sendDisconnect(), clearInterval(this.heartBeatTimer), this._heartBeatTimer = void 0, void this.resetHeartBeatOutgoing();
          var e = Ne(J.HEARTBEAT, null, this._virtualConnectionHandle);
          this.webSocketClient.sendCIPPacketWithoutBuffer(e), this.incrementHeartBeatOutgoing()
        } else clearInterval(this.heartBeatTimer)
    }, e.prototype.sendHeartBeatResponse = function(e) {
      var t = Ne(J.HEARTBEAT_RESPONSE, e, this._virtualConnectionHandle);
      this.webSocketClient.sendCIPPacketWithoutBuffer(t)
    }, e.prototype.sendDisconnect = function() {
      var e = new Uint8Array(2),
        t = 0;
      e[t++] = 0, e[t++] = 2;
      var n = Ne(J.DISCONNECT, e, this._virtualConnectionHandle);
      this.webSocketClient.sendCIPPacketWithoutBuffer(n), this.webSocketClient.closeWebSocket(!0)
    }, e.prototype.sendEndOfJoinStatusResponse = function() {
      var e = new Uint8Array(3),
        t = 0;
      e[t++] = 2, e[t++] = 3, e[t++] = 29;
      var n = Ne(J.DATA, e, this._virtualConnectionHandle);
      this.webSocketClient.sendCIPPacketWithoutBuffer(n), this.connected = !0
    }, e.prototype.sendUpdateRequest = function() {
      var e = new Uint8Array(3),
        t = 0;
      e[t++] = 2, e[t++] = 3, e[t++] = 0;
      var n = Ne(J.DATA, e, this._virtualConnectionHandle);
      this.webSocketClient.sendCIPPacketWithoutBuffer(n)
    }, e.prototype.tryReconnect = function() {
      this.webSocketClient.tryReconnect()
    }, e.prototype.disconnect = function(e) {
      this.webSocketClient.disconnect(e)
    }, e.sendUpdateTemplatePacketBuilder = function(e, t, n) {
      var i = (n ? 2 : 1) + (t ? n ? 7 : 6 : 0) + e,
        o = new Uint8Array(i),
        r = 0;
      return n ? (o[r++] = i - 2 >> 8 & 255, o[r++] = i - 2 & 255) : o[r++] = i - 1, t && (o[r++] = n ? I.EXTENDED_SMART_OBJECT : I.SMART_OBJECT, o[r++] = t >> 24 & 255, o[r++] = t >> 16 & 255, o[r++] = t >> 8 & 255, o[r++] = 255 & t, n ? (o[r++] = i - 9 >> 8 & 255, o[r++] = i - 9 & 255) : o[r++] = i - 7 & 255), {
        packetData: o,
        offset: r
      }
    }, e.prototype.sendUpdateString = function(t, n, i) {
      void 0 === i && (i = 0);
      var o = this.isUnicodeSupported ? 2 * t.length : t.length,
        r = e.sendUpdateTemplatePacketBuilder(o + 4, i, this.extendedLengthSupported),
        a = r.packetData,
        s = r.offset;
      a[s++] = this.extendedLengthSupported ? I.EXTENDED_LENGTH_SERIAL_INDIRECT_TEXT : I.SERIAL_IO_INDIRECT_TEXT, a[s++] = n >> 8 & 255, a[s++] = 255 & n, a[s++] = this.isUnicodeSupported ? 7 : 3;
      for (var c = 0; c < t.length; c++)
        if (this.isUnicodeSupported) {
          var E = t.codePointAt(c);
          a[s++] = 255 & E, a[s++] = E >> 8 & 255
        } else a[s++] = t.charCodeAt(c);
      var u = Ne(this.extendedLengthSupported ? J.EXTENDED_DATA : J.DATA, a, this.virtualConnectionHandle);
      this._webSocketClient.sendCIPPacketWithBuffer(u)
    }, e.prototype.sendUpdateNumber = function(t, n, i) {
      void 0 === i && (i = 0);
      var o = e.sendUpdateTemplatePacketBuilder(5, i, !1),
        r = o.packetData,
        a = o.offset;
      r[a++] = I.SYMMETRICAL_ANALOG_PACKETS, r[a++] = n >> 8 & 255, r[a++] = 255 & n, r[a++] = t >> 8 & 255, r[a++] = 255 & t;
      var s = Ne(J.DATA, r, this.virtualConnectionHandle);
      this._webSocketClient.sendCIPPacketWithBuffer(s)
    }, e.prototype.sendUpdateBoolean = function(t, n, i, o) {
      void 0 === i && (i = 0), void 0 === o && (o = !1);
      var r = e.sendUpdateTemplatePacketBuilder(3, i, !1),
        a = r.packetData,
        s = r.offset;
      a[s++] = o ? I.REPEAT_DIGITAL_IO : I.DIGITAL_IO, !0 === t ? (a[s++] = 255 & n, a[s++] = n >> 8 & 255) : (a[s++] = 255 & n, a[s++] = 128 + (n >> 8 & 255));
      var c = Ne(J.DATA, a, this.virtualConnectionHandle);
      this._webSocketClient.sendCIPPacketWithBuffer(c)
    }, e
  }();

  function Re(e) {
    var t = function e(t, n, i) {
      if (void 0 === n && (n = 0), void 0 === i && (i = 1), n > i) return "Object";
      var o = {};
      for (var r in t) {
        var a = t[r];
        a instanceof Object && (a = e(a, n + 1, i)), o[r] = a
      }
      return n ? o : JSON.stringify(o)
    }(e);
    return JSON.parse(t)
  }

  function Ae(e, t) {
    T({
      type: i.WEBSOCKET_EVENT,
      payload: {
        eventName: e,
        eventData: Re(t)
      }
    })
  }
  var Se = function() {
      function e() {
        this._items = [], this._isProcessing = !1
      }
      return e.prototype.size = function() {
        return this._items.length
      }, e.prototype.isEmpty = function() {
        return 0 === this._items.length
      }, e.prototype.push = function(e) {
        this._items.push(e)
      }, e.prototype.pop = function() {
        if (!this.isEmpty()) return this._items.shift();
        this._isProcessing = !1
      }, e.prototype.startProcessing = function() {
        this._isProcessing = !0
      }, e.prototype.stopProcessing = function(e) {
        void 0 === e && (e = !0), this._isProcessing = !1, e && this.clear()
      }, Object.defineProperty(e.prototype, "isProcessing", {
        get: function() {
          return this._isProcessing
        },
        enumerable: !1,
        configurable: !0
      }), e.prototype.clear = function() {
        this._items = []
      }, e
    }(),
    Oe = function() {
      function e(e, t) {
        this._isReconnecting = !1, this.url = e, this.reconnectTimeout = t || 5e3, this.cipClient = new fe(this), this.cipPacketsBuffer = new Se, this.ch5EventsBuffer = new Se, this._attemptReconnect = !1
      }
      return Object.defineProperty(e.prototype, "cipClient", {
        get: function() {
          return this._cipClient
        },
        set: function(e) {
          this._cipClient = e
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "reconnectTimeout", {
        get: function() {
          return this._reconnectTimeout
        },
        set: function(e) {
          this._reconnectTimeout = e
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "cipPacketsBuffer", {
        get: function() {
          return this._cipPacketsBuffer
        },
        set: function(e) {
          this._cipPacketsBuffer = e
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "ch5EventsBuffer", {
        get: function() {
          return this._ch5EventsBuffer
        },
        set: function(e) {
          this._ch5EventsBuffer = e
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "isReconnecting", {
        get: function() {
          return this._isReconnecting
        },
        set: function(e) {
          this._isReconnecting = e
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "socket", {
        get: function() {
          return this._socket
        },
        set: function(e) {
          this._socket = e
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(e.prototype, "connected", {
        get: function() {
          return !!this.socket && this.socket.readyState === this.socket.OPEN
        },
        enumerable: !1,
        configurable: !0
      }), e.prototype.tryReconnect = function() {
        var e = this;
        this.isReconnecting || (E.warn("Retrying WS Connection in " + this.reconnectTimeout / 1e3 + " seconds ..."), this.disconnect(), setTimeout((function() {
          e.isReconnecting = !0, e.connect()
        }), this.reconnectTimeout), this.increaseReconnectTimeout())
      }, e.prototype.connectAfterDelay = function(e) {
        var t = this;
        E.warn("Reconnecting WS Connection after " + e / 1e3 + " seconds delay..."), setTimeout((function() {
          t.connect()
        }), e)
      }, e.prototype.authenticate = function() {
        this.cipClient.authenticate()
      }, e.prototype.connect = function() {
        E.debug("Trying to establish a WebSocket connection to " + this.url), this.socket && this.disconnect(), this.socket = new WebSocket(this.url), this.socket.binaryType = "arraybuffer", this.initializeListeners(), this.isReconnecting = !1
      }, e.prototype.initializeListeners = function() {
        this.socket.onopen = this.onConnect.bind(this), this.socket.onclose = this.onClose.bind(this), this.socket.onerror = e.onError.bind(this), this.socket.onmessage = this.onMessage.bind(this)
      }, e.prototype.onConnect = function(e) {
        E.log("Successfully established WebSocket connection:", e), this.cipClient.transitionTo(a.WAIT_PROGRAM_READY), Ae(l.CONNECT_WS, e)
      }, e.prototype.onClose = function(e) {
        E.log("WebSocket connection closed:", e), this.removeEventListeners(), Ae(l.DISCONNECT_WS, e), e.wasClean ? this._attemptReconnect && (this._attemptReconnect = !1, this.tryReconnect()) : this.tryReconnect()
      }, e.onError = function(e) {
        E.log("WebSocket connection error:", e), Ae(l.ERROR_WS, e)
      }, e.prototype.onMessage = function(e) {
        this.cipClient.handleCIPPacket(e.data)
      }, e.prototype.increaseReconnectTimeout = function() {
        this.reconnectTimeout = 2 * this.reconnectTimeout % 16e4, this.reconnectTimeout = 0 === this.reconnectTimeout ? 16e4 : this.reconnectTimeout
      }, e.prototype.removeEventListeners = function() {
        E.debug("Removing all the event listeners..."), this.socket.onopen = function() {
          return {}
        }, this.socket.onclose = function() {
          return {}
        }, this.socket.onerror = function() {
          return {}
        }, this.socket.onmessage = function() {
          return {}
        }
      }, e.prototype.disconnect = function(e) {
        E.warn("Disconnecting from WebSocket..."), this.removeEventListeners(), this.socket.close(), this.socket = void 0, T({
          type: i.WEBSOCKET_EVENT,
          payload: {
            eventName: l.DISCONNECT_CIP,
            eventData: {
              reason: e
            }
          }
        }), T({
          type: i.WEBSOCKET_EVENT,
          payload: {
            eventName: l.DISCONNECT_WS
          }
        }), this.cipPacketsBuffer.stopProcessing()
      }, e.prototype.sendCIPPacketWithBuffer = function(e) {
        if (!this.connected || !this.cipClient.connected) return E.log("Not connected over CIP yet. Adding message to buffer..."), void this.cipPacketsBuffer.push(e);
        this.cipPacketsBuffer.isEmpty() ? this.socket.send(e) : this.cipPacketsBuffer.isProcessing ? (E.log("Buffer is processing. Adding message to the end of the queue..."), this.cipPacketsBuffer.push(e)) : this.startCipBufferProcessing()
      }, e.prototype.sendCIPPacketWithoutBuffer = function(e) {
        this.socket.send(e)
      }, e.prototype.onCIPConnectionStatusChanged = function(e) {
        e ? this.startCipBufferProcessing() : this.cipPacketsBuffer.stopProcessing()
      }, e.prototype.sendJoinEvent = function(e, t, n) {
        if (t) {
          var i = t.joinId - 1;
          switch (e) {
            case A.BOOLEAN:
              this.cipClient.sendUpdateBoolean(n, i, t.smartObjectId);
              break;
            case A.NUMERIC:
              this.cipClient.sendUpdateNumber(n, i, t.smartObjectId);
              break;
            case A.STRING:
              this.cipClient.sendUpdateString(n, i, t.smartObjectId);
              break;
            case A.REPEAT_DIGITAL:
              this.cipClient.sendUpdateBoolean(n, i, t.smartObjectId, !0)
          }
        }
      }, e.prototype.startCipBufferProcessing = function() {
        for (this.cipPacketsBuffer.startProcessing(); !this.cipPacketsBuffer.isEmpty();) {
          var e = this.cipPacketsBuffer.pop();
          if (!e) return;
          this.socket.send(e)
        }
      }, e.prototype.sendEventToNative = function(e) {
        if (b.initialized)
          if (this.ch5EventsBuffer.isEmpty()) {
            var t = b.mapEvent(e.eventType, e.eventName);
            this.sendJoinEvent(e.eventType, t, e.value)
          } else this.ch5EventsBuffer.push(e), this.ch5EventsBuffer.isProcessing || this.startCh5BufferProcessing();
        else this.ch5EventsBuffer.push(e)
      }, e.prototype.startCh5BufferProcessing = function() {
        for (this.ch5EventsBuffer.startProcessing(); !this.ch5EventsBuffer.isEmpty();) {
          var e = this.ch5EventsBuffer.pop(),
            t = b.mapEvent(e.eventType, e.eventName);
          this.sendJoinEvent(e.eventType, t, e.value)
        }
      }, e.prototype.closeWebSocket = function(e) {
        E.log("Calling close on websocket. Attempt reconnect ", e), this.socket.close(), this._attemptReconnect = e
      }, e
    }();
  var ve, ge = function() {
      return (ge = Object.assign || function(e) {
        for (var t, n = 1, i = arguments.length; n < i; n++)
          for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
        return e
      }).apply(this, arguments)
    },
    De = self;
  De.onmessage = function(e) {
    var t = e.data;
    switch (t.type) {
      case i.SET_BASE_PATH:
        var n = t.payload;
        D.basePath = n.value, D.getInstance().loadContractFile();
        break;
      case i.INITIALIZE_WS:
        var o = t.payload;
        Ee.setParameters(ge(ge({}, o), {
          url: new URL(o.url)
        })), be();
        break;
      case i.CONNECT_WS:
        ve.connect();
        break;
      case i.DISCONNECT_WS:
        var r = t.payload.value;
        ve.disconnect(r);
        break;
      case i.SET_JWT:
        r = t.payload.value;
        Ee.jwt = r;
        break;
      case i.AUTHENTICATE:
        ve.authenticate();
        break;
      case i.LOGGER_EVENT:
        var a = t.payload,
          s = a.enabled,
          c = a.logLevel;
        s ? E.enableDebugging() : E.disableDebugging(), E.setLogLevel(c);
        break;
      case i.BRIDGE_SEND_BOOLEAN_TO_NATIVE:
        ve.sendEventToNative({
          eventType: A.BOOLEAN,
          eventName: t.payload.signalName,
          value: t.payload.value
        }), E.debug("[WORKER] " + i.BRIDGE_SEND_BOOLEAN_TO_NATIVE, t.payload);
        break;
      case i.BRIDGE_SEND_INTEGER_TO_NATIVE:
        ve.sendEventToNative({
          eventType: A.NUMERIC,
          eventName: t.payload.signalName,
          value: t.payload.value
        }), E.debug("[WORKER] " + i.BRIDGE_SEND_INTEGER_TO_NATIVE, t.payload);
        break;
      case i.BRIDGE_SEND_STRING_TO_NATIVE:
        ve.sendEventToNative({
          eventType: A.STRING,
          eventName: t.payload.signalName,
          value: t.payload.value
        }), E.debug("[WORKER] " + i.BRIDGE_SEND_STRING_TO_NATIVE, t.payload);
        break;
      case i.BRIDGE_SEND_OBJECT_TO_NATIVE:
        E.debug("[WORKER] " + i.BRIDGE_SEND_OBJECT_TO_NATIVE, t.payload);
        var u = function(e) {
          try {
            return JSON.parse(e)
          } catch (e) {
            E.error(e)
          }
          return null
        }(t.payload.value);
        u.hasOwnProperty("repeatdigital") && ve.sendEventToNative({
          eventType: A.REPEAT_DIGITAL,
          eventName: t.payload.signalName,
          value: u.repeatdigital
        });
        break;
      default:
        E.log("Received " + t.type + " from main thread with payload: " + t.payload)
    }
  };
  var be = function() {
    try {
      ve = new Oe(Ee.url)
    } catch (e) {
      E.log(e, "Could not initialize WebSocket!")
    }
  };
  De.onerror = function(e) {
    E.error("Worker error", e)
  }
}]);
`, i.p + "d4412f0cafef4f213591.worker.js")
 