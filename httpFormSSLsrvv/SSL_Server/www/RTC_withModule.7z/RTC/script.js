import { RTCConnection } from "./RTCConnection.js";

//console.log(navigator.mediaDevices.enumerateDevices());
navigator.mediaDevices.enumerateDevices().then(mediaObtained => {
    console.log("mediaDevices:", mediaObtained);
});

// Event handlers

const loginunderAliasBut = document.querySelector('#loginAliasBut');    
loginunderAliasBut.addEventListener('click', LoginSubmitButonEvent);

var logOutundAliasBut = document.querySelector('#logOutAliasBut');    
logOutundAliasBut.addEventListener('click', LogOutSubmitButonEvent);

var singlerMsgendbut = document.querySelector('#singlemsgsendbut');    
singlerMsgendbut.addEventListener('click', onSendMSGtoSelectedUsers);

const initBtn = document.querySelector('#init_vid_btn');
initBtn.addEventListener('click', RTCConnection.init);

const callBtn = document.querySelector('#call_btn');    
callBtn.addEventListener('click', RTCConnection.call);

const hangupBtn = document.querySelector('#hangup_btn');
hangupBtn.addEventListener('click', RTCConnection.hangTheFuckingFooneEndCaal);

const brodcastBtn = document.querySelector('#brodcastbut');    
brodcastBtn.addEventListener('click', hitTheTXTbrodcast);

const msgBox = document.querySelector('#message_input');
msgBox.addEventListener('keydown', (e) => {
  if (e.keyCode === 13) hitTheTXTbrodcast(e);
})

const clearHistoryBtn = document.querySelector('#clearHistoryBtn');
clearHistoryBtn.addEventListener('click', clearChatHistory);


// trigered by broadcast button
// prevent form submiting.. 
// colect text from box
async function hitTheTXTbrodcast(e)
{
  e.preventDefault();
  var inputTXTbox = document.querySelector('#message_input');

  WsbroadcastBullshitToAllOthers(inputTXTbox.value); 

  inputTXTbox.value = ''; 
}

async function LoginSubmitButonEvent(e)
{
      e.preventDefault();
     // var logINorLOGout = !document.querySelector('.user_registration_form').classList.contains("hide")
      var logINorLOGout = true;   
      anouseAliasName(logINorLOGout); 
}
async function LogOutSubmitButonEvent(e)
{
      e.preventDefault();
      anouseAliasName(false); 
}

async function anouseAliasName(logYnOrLogOut)
{    
  let username = document.querySelector('#usernamebox').value;

  if(logYnOrLogOut == true)
  {
     if (username && username !== "") {
       document.querySelector('.user_registration_form').classList.add('hide');
       document.querySelector('.user_profile_wrapper > div').classList.remove('hide');
     } else {
       document.querySelector('.user_registration_form').classList.remove('hide');
     }
     document.querySelector('.user_profile_wrapper > div > p').innerHTML = username;
  }
  else
  {
       document.querySelector('.user_profile_wrapper > div').classList.add('hide');
       document.querySelector('.user_registration_form').classList.remove('hide');
  }
  if(logYnOrLogOut == true)  
  WsAnouceLoginAliasName();
   else
  WsAnouceLogOUTbyAliasName();
} 

function clearChatHistory(e) {
  e.preventDefault();
  var slanderWallOfShame = document.querySelector("#podium_inner_common_table tbody");
  if(slanderWallOfShame)
   slanderWallOfShame.innerHTML ="";
}

async function onSendMSGtoSelectedUsers(e)
{
   e.preventDefault();
   SendMSGtoSelectedUsers(e);
}



globalThis.ex_anouseAliasName = anouseAliasName;
globalThis.ex_RTCConnection = RTCConnection;









