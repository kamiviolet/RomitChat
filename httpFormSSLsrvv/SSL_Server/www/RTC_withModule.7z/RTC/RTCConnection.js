export class RTCConnection {
  static startTime;
  static localStream;
  static local;
  static remote;

  static constraints = window.constraints = {
    audio: true,
    video: true
  };
  static offerOptions = {
    offerToReceiveAudio: 1,
    offerToReceiveVideo: 1
  };


  static async init(e) {
    e.preventDefault();

    const initBtn = document.querySelector('#init_vid_btn');
    const callBtn = document.querySelector('#call_btn');   

    initBtn.disabled = true;
    callBtn.disabled = false;

    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      RTCConnection.handleInitSuccess(stream);

    } catch (e) {
      handleError(e);
    }
  }


  static handleInitSuccess(stream) {
    const localCam = document.querySelector('#local_cam');
    localCam.srcObject = stream;

    RTCConnection.localStream = stream;
  }


  static async call() {
    const callBtn = document.querySelector('#call_btn');    
    const hangupBtn = document.querySelector('#hangup_btn');

    callBtn.disabled = true;
    hangupBtn.disabled = false;

    RTCConnection.startTime = window.performance.now();

    const configuration = {};

    console.log('RTCPeerConnection configuration:', configuration);

    RTCConnection.local = new RTCPeerConnection(configuration);
    
    console.log('Created local peer connection object local');

    RTCConnection.local.addEventListener('icecandidate', e => {
      console.log("onIceCandidate", e);
      onIceCandidate(local, e);
    });

    try {
      console.log('Local createOffer start');
      const offer = await local.createOffer(offerOptions);
      await RTCConnection.onCreateOfferSuccess(offer, local);
    } catch (e) {
      RTCConnection.onCreateSessionDescriptionError(e);
    }
  }


  static async onIceCandidate(pc, event) {
    try {
      await (getOtherPc(pc).addIceCandidate(event.candidate));
      RTCConnection.onAddIceCandidateSuccessOrErr(pc);//onAddIceCandidateSuccess(pc);
    } catch (e) {
      //onAddIceCandidateError(pc, e);
      RTCConnection.onAddIceCandidateSuccessOrErr(pc, e);
    }
    console.log(`${getName(pc)} ICE candidate:\n${event.candidate ? event.candidate.candidate : '(null)'}`);
  }


  static async onCreateOfferSuccess(desc, somepeercon) { 
    somepeercon.setLocalDescription(desc); 
  }


  static onAddIceCandidateSuccessOrErr(somepeer, possibleErr) {
    if (!possibleErr) {
      console.log("onAddIceCandidateSuccessOrErr OK > ", somepeer);
    } else {
      console.log("onAddIceCandidateSuccessOrErr ERR >", somepeer, possibleErr);
    }
  }


  static async hangTheFuckingFooneEndCaal(e)
  {
      e.preventDefault();
  }


  // Error handling
  static handleError(error) {
    if (error.name === 'OverconstrainedError') {
      errorMsg(`OverconstrainedError: The constraints could not be satisfied by the available devices. Constraints: ${JSON.stringify(constraints)}`);
    } else if (error.name === 'NotAllowedError') {
      errorMsg('NotAllowedError: Permissions have not been granted to use your camera and ' +
        'microphone, you need to allow the page access to your devices in ' +
        'order for the demo to work.');
    }
    errorMsg(`getUserMedia error: ${error.name}`, error);
  }

  static errorMsg(msg, error) {
    const errorElement = document.querySelector('#errorMsg');
    errorElement.innerHTML += `<p>${msg}</p>`;

    if (typeof error !== 'undefined') {
      console.error(error);
    }
  }

  static onCreateSessionDescriptionError(error) {
    console.log(`Failed to create session description: ${error.toString()}`);
  }

  static onSetSessionDescriptionError(error) {
    console.log(`Failed to set session description: ${error.toString()}`);
  }
}